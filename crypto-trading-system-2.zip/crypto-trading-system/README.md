# 加密貨幣交易決策系統 — V0.1 + V0.2

> ⚠️ 本系統僅供交易決策參考，不構成投資建議，不保證獲利。所有評分、訊號、回測結果都可能出錯或失效，請自行承擔交易風險。

依照開發規格書，本階段完成 **V0.1（儀表板 / 資金階段管理）** 與 **V0.2（技術指標 / Opportunity Score / Risk Score / 交易訊號）**。尚未包含山寨幣自動排名（V0.3）、回測與 Paper Trading（V0.4）、Telegram 通知（V0.5）、進階風控如 Profit Lock 微調（V0.6）——架構已預留，之後可逐步擴充。

## 快速開始

需要 Node.js 18+。

```bash
npm install
npm run dev
```

打開 http://localhost:3000 （用手機瀏覽器開發時建議用區網 IP，例如 `npm run dev -- -H 0.0.0.0`）。

不需要任何 API Key。所有資料來源皆為免費公開 API：

- **CoinGecko 免費版**（幣價、市值、24H量、歷史小時線）— 有速率限制，前端每 60 秒才自動刷新一次，勿改更短。
- **alternative.me Fear & Greed Index**（免費、無需金鑰）。

## 已實作功能對照規格書

| 規格書章節 | 實作狀態 |
|---|---|
| 二、每日交易判斷（🟢🟡🔴） | ✅ `lib/dailyState.ts` |
| 三、每日自動掃描（BTC/ETH/SOL/BNB/XRP/DOGE） | ✅ `lib/coingecko.ts` DEFAULT_WATCHLIST（V0.3 會改為動態排名） |
| 五、Opportunity Score | ✅ `lib/scoring.ts`（技術面 35% + 動能 25% + 量能 20% + 基本面佔位 20%，再依市場面/情緒面/風險旗標加減分） |
| 九、風控／單筆最大風險 | ✅ `lib/phases.ts` `effectiveMaxRiskPct` |
| 十、倉位計算器 | ✅ `lib/phases.ts` `calcPositionSize` |
| 十二、Meme／追高偵測（DO NOT CHASE） | ✅ `lib/scoring.ts` chaseRisk 判斷 |
| 十五、牛熊市場判斷（BULL/SIDEWAYS/BEAR/EUPHORIA/PANIC） | ✅ `lib/scoring.ts` `classifyMarketRegime` |
| 十六、十七、資金階段自動切換 | ✅ `lib/phases.ts` PHASES |
| 十八、獲利保護 Profit Lock | ✅ `lib/phases.ts`（回撤 10/15/20% 三段） |
| 二十六、二十七、Dashboard／機會詳情頁 | ✅ `app/page.tsx` + `components/OpportunityCard.tsx` |
| 三十二、資料來源錯誤顯示 | ✅ 任何 API 失敗會顯示 `⚠️ DATA SOURCE ERROR`，絕不使用假資料頂替 |

尚未實作（依照規格書開發順序，留待下一階段）：

- V0.3：山寨幣市值排名動態掃描、完整突破/假突破偵測、資金流／大額交易資料
- V0.4：Backtest（勝率、Profit Factor、Sharpe…）與 Paper Trading 模擬帳本、交易日誌
- V0.5：Telegram / Discord / Email 通知、每日固定報告
- V0.6：更細緻的 Profit Lock 分級、系統自我評估（每100筆交易分析）
- 基本面資料（Token Unlock、TVL、開發活躍度…）目前以中性權重佔位，尚未串接資料源

## 目前的評分方法（會持續調整，非黑箱）

- **Trend Score**：價格相對 EMA20/EMA50/EMA200 排列
- **Momentum Score**：RSI14 是否落在健康區間 + MACD 柱狀圖方向
- **Volume Score**：24H 成交量／市值比（換手率）當作資金關注度的簡化代理指標
- **Risk Score**：過熱（RSI≥82）、流動性不足、疑似假突破、追高風險、大盤處於 PANIC/EUPHORIA、波動度(ATR/price) 皆會提高風險分數
- 停損採 ATR×1.5（限制在 3%~12% 之間），TP1/TP2/TP3 分別為 1.5R / 3R / 5R

這些都是**規則式**計算，不是 AI 直接判斷買賣——符合規格書第二十二節「AI 不能直接決定一定買」的要求（目前版本尚未接入 AI 輔助解讀，屬於 OPTIONAL 功能，未來可用免費/自架模型加上去，不影響核心規則運作）。

## 專案結構

```
app/
  layout.tsx        全域 layout（手機優先、深色主題）
  page.tsx           主儀表板（client component，60秒輪詢）
  globals.css
components/
  OpportunityCard.tsx  機會卡片（含展開詳情：進場/停損/TP/理由/失效條件）
lib/
  types.ts            核心型別
  coingecko.ts         免費公開資料來源 client
  indicators.ts        EMA/RSI/MACD/ATR/Bollinger 純函式
  scoring.ts            Opportunity Score / Risk Score / Regime 分類
  phases.ts              資金階段、風控、倉位計算、Profit Lock
  dailyState.ts           今日🟢🟡🔴判斷邏輯
```

## 下一步建議

先確認這版能在你手機上正常打開、抓到真實 BTC/ETH 報價與市場狀態、資金階段顯示正確，再回報要繼續做 V0.3（山寨幣掃描 + 假突破偵測強化）還是 V0.4（回測 + Paper Trading）。
